# Change Log

## [1.1.0] 2019-03-14
### Changes
- update to Angular 7
- update to ng-bootstrap 4
- update all dependences
- fixed datepicker design
- changed sign up page from index with login page
- changed icons
- fixed badges design

## [1.0.1] 2018-05-21
### Changes
- changed GitHub repository

## [1.0.0] 2018-03-08
### Initial Release
